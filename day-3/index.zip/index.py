import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    
    # Launch EC2 instance
    response = ec2.run_instances(
        ImageId='ami-0abcd1234efgh5678',  # Replace with your AMI ID
        InstanceType='t2.micro',           # Replace with your instance type
        MinCount=1,
        MaxCount=1
    )
    
    # Return the instance ID
    return {
        'statusCode': 200,
        'body': f"EC2 Instance {response['Instances'][0]['InstanceId']} launched successfully!"
    }
